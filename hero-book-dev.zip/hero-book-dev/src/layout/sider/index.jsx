
// style
import "./styles.scss"
import AccordionUsage from '../../components/siderAccordion/SiderAcordion'

const Sider = () => {
  return (
    <div>
      <AccordionUsage/>
    </div>
  )
}

export default Sider