import logo from "./img/logo.png";
import facebook from "./img/f.png";
import bmIcon from "./img/bm.png";
import casinoImg from "./img/casinoImg.jpg";
import baccart from "./img/baccarat.jpg";
import plus18 from "./img/18plus.png";
import faceboo from "./img/facebook.png";
import instagram from "./img/instagram.png";
import telegram from "./img/telegram.png";
import whatsApp from "./img/whatsapp.png";
import defaultImg from "./img/default.jpg";

export {defaultImg,logo,facebook,bmIcon,casinoImg,baccart,plus18,faceboo,telegram,instagram,whatsApp}