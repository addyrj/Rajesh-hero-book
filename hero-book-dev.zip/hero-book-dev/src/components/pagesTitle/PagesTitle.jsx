///styles
import "./styles.scss"
const PagesTitle = ({ title }) => {
  return (
    <div className="satement-header"><h4 className="header-title">{title}</h4></div>
  )
}

export default PagesTitle