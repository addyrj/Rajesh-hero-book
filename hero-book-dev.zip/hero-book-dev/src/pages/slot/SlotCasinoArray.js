export const SlotCasinoArray = [
    {
        "id": "901001",
        "name": "RG",
        "url": "https://herobook.in/images/Race_to_17_slot.jpg",
    },
    {
        "id": "901002",
        "name": "RG",
        "url": "https://herobook.in/images/3_card_judgement_slot.jpg",
    },
    {
        "id": "901003",
        "name": "RG",
        "url": "https://herobook.in/images/7up&down_slot.jpg",
    },
    {
        "id": "901004",
        "name": "RG",
        "url": "https://herobook.in/images/32_Cards_slot.jpg",
    },
    {
        "id": "901005",
        "name": "RG",
        "url": "https://herobook.in/images/Amar_Akbar_Anthony_slot.jpg",
    },
    {
        "id": "901006",
        "name": "RG",
        "url": "https://herobook.in/images/Andar_bahar_slot.jpg",
    },
    {
        "id": "901007",
        "name": "RG",
        "url": "https://herobook.in/images/Baccarat_slot.jpg",
    },
    {
        "id": "901008",
        "name": "RG",
        "url": "https://herobook.in/images/Center_Card_slot.jpg",
    },
    {
        "id": "901009",
        "name": "RG",
        "url": "https://herobook.in/images/dragon_tiger_lobby_slot.jpg",
    },
    {
        "id": "901010",
        "name": "RG",
        "url": "https://herobook.in/images/HI_LO_slot.jpg",
    },
    {
        "id": "901011",
        "name": "RG",
        "url": "https://herobook.in/images/Race_T20_slot.jpg",
    },
    {
        "id": "901013",
        "name": "RG",
        "url": "https://herobook.in/images/roulette_lobby_slot.jpg",
    },
    {
        "id": "901014",
        "name": "RG",
        "url": "https://herobook.in/images/Super_Over_one_day_slot.jpg",
    },
    {
        "id": "901015",
        "name": "RG",
        "url": "https://herobook.in/images/Super_Over_slot.jpg",
    },
    {
        "id": "901016",
        "name": "RG",
        "url": "https://herobook.in/images/Teenpatti2_slot.jpg",
    },
    {
        "id": "901017",
        "name": "RG",
        "url": "https://herobook.in/images/Teen_patti_one_day_slot.jpg",
    },
    {
        "id": "901018",
        "name": "RG",
        "url": "https://herobook.in/images/Teen_Patti_one_day_slot.jpg",
    },
    {
        "id": "901019",
        "name": "RG",
        "url": "https://herobook.in/images/Teenpatti_slot.jpg",
    },
    {
        "id": "901020",
        "name": "RG",
        "url": "https://herobook.in/images/Worli_matka_slot.jpg",
    },
    {
        "id": "901021",
        "name": "RG",
        "url": "https://herobook.in/images/Bollywood_Casino_slot.jpg",
    },
    {
        "id": "901022",
        "name": "RG",
        "url": "https://herobook.in/images/Casino_Meter_slot.jpg",
    },
    {
        "id": "901023",
        "name": "RG",
        "url": "https://herobook.in/images/Cricket_War_slot.jpg",
    },
    {
        "id": "901024",
        "name": "RG",
        "url": "https://herobook.in/images/Dus_Ka_Dum_slot.jpg",
    },
    {
        "id": "901025",
        "name": "RG",
        "url": "https://herobook.in/images/Foot_Ball_Studio_slot.jpg",
    },
    {
        "id": "901026",
        "name": "RG",
        "url": "https://herobook.in/images/High_Card_slot.jpg",
    },
    {
        "id": "901027",
        "name": "RG",
        "url": "https://herobook.in/images/Movie_Casino_slot.jpg",
    },
    {
        "id": "901028",
        "name": "RG",
        "url": "https://herobook.in/images/Muflis_One_day_slot.jpg",
    },
    {
        "id": "901029",
        "name": "RG",
        "url": "https://herobook.in/images/muflis_teenpatti_lobby_slot.jpg",
    },
    {
        "id": "901030",
        "name": "RG",
        "url": "https://herobook.in/images/Queen_Race_slot.jpg",
    },
    {
        "id": "901031",
        "name": "RG",
        "url": "https://herobook.in/images/Roulette_slot.jpg",
    },
    {
        "id": "901032",
        "name": "RG",
        "url": "https://herobook.in/images/Side_Bet_City_slot.jpg",
    },
    {
        "id": "901033",
        "name": "RG",
        "url": "https://herobook.in/images/The_Trap_slot.jpg",
    },
    {
        "id": "901034",
        "name": "RG",
        "url": "https://herobook.in/images/Trio_slot.jpg",
    },
]