export const casinoArray = [{
  casinoType: "ALL CASINO",
  link: "ALL_CASINO",
  casinoName: "ourCasino"
}, {
  casinoType: "ROULETTE",
  link: "ROULETTE",
  casinoName: "ourCasino"
},
{
  casinoType: "TEENPATTI",
  link: "TEENPATTI",
  casinoName: "ourCasino"
},
{
  casinoType: "POKER",
  link: "POKER",
  casinoName: "ourCasino"
},
{
  casinoType: "BACCARAT",
  link: "BACCARAT",
  casinoName: "ourCasino"
},
{
  casinoType: "DRAGON TIGER",
  link: "DRAGON_TIGER",
  casinoName: "ourCasino"
},
{
  casinoType: "32 CARD",
  link: "32_CARD",
  casinoName: "ourCasino"
},
{
  casinoType: "ANDAR BAHAR",
  link: "ANDAR_BAHAR",
  casinoName: "ourCasino"
},
{
  casinoType: "Lucky 7",
  link: "Lucky_7",
  casinoName: "ourCasino"
},
{
  casinoType: "3 CARD JUDGEMENT",
  link: "3_CARD_JUDGEMENT",
  casinoName: "ourCasino"
},
{
  casinoType: "CASINO WAR",
  link: "CASINO_WAR",
  casinoName: "ourCasino"
},

{
  link: "WORLI",
  casinoType: "WORLI",
  casinoName: "ourCasino"
},
{
  link: "SPORTS",
  casinoType: "Sport",
  casinoName: "ourCasino"
},
{
  casinoType: "BOLLYWOOD",
  link: "BOLLYWOOD",
  casinoName: "ourCasino"
},
{
  casinoType: "LOTTERY",
  link: "LOTTERY",
  casinoName: "ourCasino"
},
{
  casinoType: "QUEEN",
  link: "QUEEN",
  casinoName: "ourCasino"
},
{
  casinoType: "RACE",
  link: "RACE",
  casinoName: "ourCasino"
},
{
  casinoType: "OTHERS",
  link: "OTHERS",
  casinoName: "ourCasino"
}
  ,
{
  casinoType: "All Casino",
  link: "ALL_CASINO",
  casinoName: "our-virtual"
},
{
  casinoType: "TEENPATTI",
  link: "TEENPATTI", casinoName: "our-virtual"
},
{
  casinoType: "Dragon Tiger",
  link: "DRAGON_TIGER", casinoName: "our-virtual"
},
{
  casinoType: "Lucky 7",
  link: "Lucky_7", casinoName: "our-virtual"
},
{
  casinoType: "Bollywood",
  link: "BOLLYWOOD", casinoName: "our-virtual"
},
{
  casinoType: "Others",
  link: "OTHERS", casinoName: "our-virtual"
}
];
