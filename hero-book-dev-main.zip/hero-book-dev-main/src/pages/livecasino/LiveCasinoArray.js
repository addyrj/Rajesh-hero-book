export const liveCasino = [
  {
    name: "Evolution",
    id: "200215",
    casinoName: "EVOLUTION"
  },
  {
    name: "Ezugi",
    id: "100000",
    casinoName: "EZUGI"
  },
  {
    name: "Royal Gaming",
    id: "900000",
    casinoName: "ROYAL_GAMING"
  },
  {
    name: "A E Sexy",
    id: "400000",
    casinoName: "A_E_SEXY"
  },
  {
    name: "Virtual Sports Betting",
    id: "800001",
    casinoName: "VIRTUAL_SPORTS_BETTING"
  },
  {
    name: "Jili",
    id: "600000",
    casinoName: "JILI"
  },
  {
    name: "Ludo Gaming",
    id: "600113",
    casinoName: "LUDO_GAMING"
  },
  {
    name: "Aviator",
    id: "201206",
    casinoName: "AVIATOR"
  },
  {
    name: "Supernova 7",
    id: "500001",
    casinoName: "SUPERNOVA7"
  },
  {
    name: "Fortune Is In Your Hand",
    id: "201153",
    casinoName: "FORTUNE_IS_IN_YOUR_HAND"
  },
]